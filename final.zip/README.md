# CSE 100 Project 1

__Checkpoint Deadline:__ 11:59 PM on Friday, 01/18 (not eligible for slip day)

__Final Deadline:__ 11:59 PM on Friday, 01/25 (slip day eligible)
